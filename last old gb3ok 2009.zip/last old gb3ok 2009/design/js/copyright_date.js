// JavaScript Document

function copyright()
{
var now         = new Date();
var year        = now.getYear();
if (year < 1900){
year = year + 1900;
}
return year;
}
/***********************************************************************************
*	(c) Ger Versluis 2000 version 5.411 24 December 2001 
*   (updated Jan 31st, 2003 by Dynamic Drive for Opera7)
*	For info write to menus@burmees.nl		          
*   For latest menus goto http://www.burmees.nl/menu/menus.htm
*	You may remove all comments for faster loading	          		
***********************************************************************************/

	var NoOffFirstLineMenus=6;			// Number of first level items
	var LowBgColor='#666666'; 			// Background color when mouse is not over
	var LowSubBgColor='white';  		// Background color when mouse is not over on subs
	var HighBgColor='#999999';			// Background color when mouse is over
	var HighSubBgColor='#999999';		// Background color when mouse is over on subs
	var FontLowColor='#FFFFFF';			// Font color when mouse is not over
	var FontSubLowColor='#CC0000';		// Font color subs when mouse is not over
	var FontHighColor='#FFFF00';		// Font color when mouse is over
	var FontSubHighColor='white';		// Font color subs when mouse is over
	var BorderColor='#CCCCCC';			// Border color
	var BorderSubColor='#CCCCCC'; 		// Border color for subs
	var BorderWidth=1;					// Border width
	var BorderBtwnElmnts=1;				// Border between elements 1 or 0
	var FontFamily="arial,comic sans ms,technical"	// Font family menu items
	var FontSize=9;						// Font size menu items
	var FontBold=1;						// Bold menu items 1 or 0
	var FontItalic=0;					// Italic menu items 1 or 0
	var MenuTextCentered='left';		// Item text position 'left', 'center' or 'right'
	var MenuCentered='left';			// Menu horizontal position 'left', 'center' or 'right'
	var MenuVerticalCentered='top';		// Menu vertical position 'top', 'middle','bottom' or static
	var ChildOverlap=.2;				// horizontal overlap child/ parent
	var ChildVerticalOverlap=.2;		// vertical overlap child/ parent
	var StartTop=0;						// Menu offset x coordinate
	var StartLeft=0;					// Menu offset y coordinate
	var VerCorrect=0;					// Multiple frames y correction
	var HorCorrect=0;					// Multiple frames x correction
	var LeftPaddng=6;					// Left padding
	var TopPaddng=2;					// Top padding
	var FirstLineHorizontal=1;			// SET TO 1 FOR HORIZONTAL MENU, 0 FOR VERTICAL
	var MenuFramesVertical=1;			// Frames in cols or rows 1 or 0
	var DissapearDelay=300;				// delay before menu folds in milliseconds
	var TakeOverBgColor=1;				// Menu frame takes over background color subitem frame
	var FirstLineFrame='navig';			// Frame where first level appears
	var SecLineFrame='space';			// Frame where Sub Levels appear
	var DocTargetFrame='space';			// Frame where target documents appear
	var TargetLoc='menuline';			// span id for relative positioning
	var HideTop=0;						// Hide first level when loading new document 1 or 0
	var MenuWrap=1;						// enables/ disables menu wrap 1 or 0
	var RightToLeft=0;					// enables/ disables right to left unfold 1 or 0
	var UnfoldsOnClick=0;				// Level 1 unfolds onclick/ onmouseover
	var WebMasterCheck=0;				// menu tree checking on or off 1 or 0
	var ShowArrow=1;					// Uses arrow gifs when 1
	var KeepHilite=1;					// Keep selected path highligthed
	var Arrws=['design/menu/tri.gif',5,10,'design/menu/tridown.gif',10,5,'design/menu/trileft.gif',5,10];	// Arrow source, width and height

function BeforeStart(){return}
function AfterBuild(){return}
function BeforeFirstOpen(){return}
function AfterCloseAll(){return}


// Menu tree
//	MenuX=new Array("Text to show","Link","background image (optional)",number of sub elements,height,width);

//	For rollover images set "Text to show" to:  "rollover:Image1.jpg:Image2.jpg"
//  Test rollover line = rollover:design/menu/menu_1.gif:design/menu/menu_2.gif
/* ----- Menu Level 1 ----- */
Menu1=new Array("Events and News","homepage.html","design/images/bg_silver_nav.jpg",0,20,127);
//  try also - javascript:history.back(1) - javascript:history.go(-1);
/* ----- Menu Level 2 ----- */
Menu2=new Array("BRG General","","design/images/bg_silver_nav.jpg",4);
	Menu2_1=new Array("Help to Support Us","donation_support.html","",0,20,140);
	Menu2_2=new Array("Supporting Members","supporting_members.html","",0);
	Menu2_3=new Array("Good Operator","goodoperator.html","",0);
	Menu2_4=new Array("Bad Operator","jammers.html","",0);
	Menu2_5=new Array("Spare Item 5","#","",0);
	Menu2_6=new Array("Spare Item 6","#","",0);
	Menu2_7=new Array("Spare Item 7","#","",0);
	Menu2_8=new Array("Spare Item 8","#","",0);
/* ----- Menu Level 3 ----- */
Menu3=new Array("The Repeaters","","design/images/bg_silver_nav.jpg",2);
	Menu3_1=new Array("GB3OK","","",3,20,140);
		Menu3_1_1=new Array("History","history.html","",0,20,140);
	    Menu3_1_2=new Array("Echolink","echolink.html","",0);
	    Menu3_1_3=new Array("Technical","gb3ok_technical.html","",0);	
    Menu3_2=new Array("GB7OK","","",5,20,140);
		Menu3_2_1=new Array("GB7OK Home","gb7ok_homepage.html","",0,20,140);
	    Menu3_2_2=new Array("D-STAR Explained","dstar_explained.html","",0);
	    Menu3_2_3=new Array("D-STAR Downloads","gb7ok_downloads.html","",0);
		Menu3_2_4=new Array("Technical","gb7ok_technical.html","",0);
		Menu3_2_5=new Array("Last Heard on GB7OK","javascript:NewWin=window.open('http://www.jfindu.net/dstarlh.aspx?rptr=GB7OK','NWin');window['NewWin'].focus()","",0);	
	Menu3_3=new Array("Spare Item 3","#","",0);
	Menu3_4=new Array("Spare Item 4","#","",0);
	Menu3_5=new Array("Spare Item 5","#","",0);
	Menu3_6=new Array("Spare Item 6","#","",0);
	Menu3_7=new Array("Spare Item 7","#","",0);
	Menu3_8=new Array("Spare Item 8","#","",0);
/* ----- Menu Level 4 ----- */
Menu4=new Array("Miscellaneous","","design/images/bg_silver_nav.jpg",5);
	Menu4_1=new Array("Amateur Radio News","sarc_newsfeed.html","",0,20,140);
	Menu4_2=new Array("BRG Search","google_search.html","",0);
	Menu4_3=new Array("World Clock","world_clock.html","",0);
	Menu4_4=new Array("Q-Codes","q_codes.html","",0);
	Menu4_5=new Array("Sitemap","sitemap.html","",0);
	Menu4_6=new Array("Spare Item 6","#","",0);
	Menu4_7=new Array("Spare Item 7","#","",0);
	Menu4_8=new Array("Spare Item 8","#","",0);
/* ----- Menu Level 5 ----- */
Menu5=new Array("Links","","design/images/bg_silver_nav.jpg",6);
	Menu5_1=new Array("Member's Links","links_members.html","",0,20,140);
	Menu5_2=new Array("Club Links","links_clubs.html","",0);
	Menu5_3=new Array("Retail Links","links_retail.html","",0);
	Menu5_4=new Array("Special Offers","lynch_offer_01.html","",0);
	Menu5_5=new Array("Phonesniffer","javascript:NewWin=window.open('http://www.sitedreams.com/ccount/click.php?id=14','NWin');window['NewWin'].focus()","",0);
	Menu5_6=new Array("Web Hosting","javascript:NewWin=window.open('http://www.sitedreams.com/ccount/click.php?id=16','NWin');window['NewWin'].focus()","",0);
    Menu5_7=new Array("Spare Item 7","#","",0); // < Change 'n' to suit number of sub menus below
	Menu5_8=new Array("Spare Item 8","#","",0);
/* ----- Menu Level 6 ----- */
Menu6=new Array("Community","","design/images/bg_silver_nav.jpg",5);
    Menu6_1=new Array("Forum","javascript:NewWin=window.open('http://www.sitedreams.com/cgi-bin/radio/ikonboard.cgi','NWin');window['NewWin'].focus()","",0,20,140);
	Menu6_2=new Array("Guestbook","guestbook2.html","",0);
	Menu6_3=new Array("Old Guestbook","guestbook_archived.html","",0);
	Menu6_4=new Array("Contact Us","contact_us.html","",0);
	Menu6_5=new Array("Credits","brg_credits.html","",0);
	Menu6_6=new Array("Spare Item 6","#","",0);
    Menu6_7=new Array("Spare Item 7","","",5,20,140); // < Change 'n' to suit number of sub menus below
		Menu6_7_1=new Array("Spare Sub Item One","#","",0,20,140);
	    Menu6_7_2=new Array("Spare Sub Item Two","#","",0);
	    Menu6_7_3=new Array("Spare Sub Item Three","#","",0);
	    Menu6_7_4=new Array("Spare Sub Item Four","#","",0);
	    Menu6_7_5=new Array("Spare Sub Item Five","#","",0);		
	Menu6_8=new Array("404 Page","404.html","",0);
		